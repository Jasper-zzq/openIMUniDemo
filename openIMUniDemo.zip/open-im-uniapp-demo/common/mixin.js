export default {
  data() {
    return {};
  },
};
