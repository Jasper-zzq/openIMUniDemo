import ic_avatar_01 from "static/defaultAvatars/ic_avatar_01.png";
import ic_avatar_02 from "static/defaultAvatars/ic_avatar_02.png";
import ic_avatar_03 from "static/defaultAvatars/ic_avatar_03.png";
import ic_avatar_04 from "static/defaultAvatars/ic_avatar_04.png";
import ic_avatar_05 from "static/defaultAvatars/ic_avatar_05.png";
import ic_avatar_06 from "static/defaultAvatars/ic_avatar_06.png";

const avatars = {
  ic_avatar_01: ic_avatar_01,
  ic_avatar_02: ic_avatar_02,
  ic_avatar_03: ic_avatar_03,
  ic_avatar_04: ic_avatar_04,
  ic_avatar_05: ic_avatar_05,
  ic_avatar_06: ic_avatar_06,
};

export default avatars;
