uni.$u.props.gap.bgColor = "#f3f4f6";
uni.$u.props.gap.height = "10";
