<template>
  <view class="text_message_container bg_container">
    <view> [暂未支持的消息类型] </view>
  </view>
</template>

<script>
export default {
  name: "ErrorMessagegRender",
  components: {},
  data() {
    return {};
  },
};
</script>

<style lang="scss" scoped></style>
