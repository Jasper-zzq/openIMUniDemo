## 3.6.5（2022-10-14）
修复组件size值为string类型时，调用toTempFilePath导出临时文件路径失败；  
优化组件加载本地图片。
