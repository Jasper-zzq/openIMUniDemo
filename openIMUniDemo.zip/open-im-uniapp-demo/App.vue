<script>
import { mapGetters, mapActions } from "vuex";
import {
  MessageReceiveOptType,
  MessageType,
  SessionType,
} from "open-im-sdk";



import config from "@/common/config";
import { getDbDir, toastWithCallback } from "@/util/common.js";
import { conversationSort } from "@/util/imCommon";
import { PageEvents } from "@/constant";
import { checkUpdateFormPgyer } from "@/api/checkUpdate";
import NotificationUtil from "./util/notification";
import newMessage from "@/static/audio/newMessage.wav";
import { getSDK } from "./util/common";

let cacheConversationList = [];
let updateDownloadTask = null;
let notificationIntance = null;
let pausing = false;
let innerAudioContext;

let IMSDK = getSDK()

export default {
  onLaunch: function () {
    console.log("App Launch");
    // Igexin.turnOnPush();
    innerAudioContext = uni.createInnerAudioContext();
    innerAudioContext.autoplay = false;
    innerAudioContext.src = newMessage;

    this.$store.dispatch("user/getAppConfig");
    this.launchCheck();
    this.setGlobalIMlistener();
    this.setPageListener();
    this.tryLogin();
  },
  onReady: function () {
    /* #ifdef APP-PLUS */
    plus.navigator.setStatusBarStyle('dark');
    /* #endif */
  },
  onShow: function () {
    console.log("App Show", IMSDK);
    IMSDK.setAppBackgroundStatus("IMSDK.uuid()", false)
    /* #ifdef APP-PLUS */
    plus.navigator.setStatusBarStyle('dark');
    /* #endif */
  },
  onHide: function () {
    console.log("App Hide");
    IMSDK.setAppBackgroundStatus(IMSDK.uuid(), true)
  },
  computed: {
    ...mapGetters([
      "storeConversationList",
      "storeCurrentConversation",
      "storeCurrentUserID",
      "storeSelfInfo",
      "storeRecvFriendApplications",
      "storeRecvGroupApplications",
      "storeHistoryMessageList",
      "storeIsSyncing",
    ]),
    contactBadgeRely() {
      return {
        recvFriendApplications: this.storeRecvFriendApplications,
        recvGroupApplications: this.storeRecvGroupApplications,
        userKey: this.storeCurrentUserID,
      };
    },
  },
  methods: {
    ...mapActions("message", [
      "pushNewMessage",
      "updateOneMessage",
      "updateMessageNicknameAndFaceUrl",
    ]),
    ...mapActions("conversation", ["updateCurrentMemberInGroup"]),
    ...mapActions("contact", [
      "updateFriendInfo",
      "pushNewFriend",
      "updateBlackInfo",
      "pushNewBlack",
      "pushNewGroup",
      "updateGroupInfo",
      "pushNewRecvFriendApplition",
      "updateRecvFriendApplition",
      "pushNewSentFriendApplition",
      "updateSentFriendApplition",
      "pushNewRecvGroupApplition",
      "updateRecvGroupApplition",
      "pushNewSentGroupApplition",
      "updateSentGroupApplition",
    ]),
    setGlobalIMlistener() {
      console.log("setGlobalIMlistener");
      // init
      const kickHander = (message) => {
        toastWithCallback(message, () => {
          uni.removeStorage({
            key: "IMToken",
          });
          uni.removeStorage({
            key: "BusinessToken",
          });
          // Igexin.unbindAlias(this.storeCurrentUserID)
          uni.$u.route("/pages/login/index");
        });
      };
      IMSDK.subscribe(IMSDK.IMEvents.OnConnectFailed, ({ errCode }) => {
        console.log(errCode);
      });
      IMSDK.subscribe(IMSDK.IMEvents.OnConnecting, (data) => {
        console.log(data);
      });
      IMSDK.subscribe(IMSDK.IMEvents.OnConnectSuccess, (data) => {
        console.log(data);
      });
      IMSDK.subscribe(IMSDK.IMEvents.OnKickedOffline, (data) => {
        kickHander("您的账号在其他设备登录，请重新登陆！");
      });
      IMSDK.subscribe(IMSDK.IMEvents.OnUserTokenExpired, (data) => {
        kickHander("您的登录已过期，请重新登陆！");
      });

      // sync
      const syncStartHandler = () => {
        uni.showLoading({
          title: "同步中",
          mask: true,
        });
        this.$store.commit("user/SET_IS_SYNCING", true);
      };
      const syncFinishHandler = () => {
        uni.hideLoading();
        this.$store.dispatch("conversation/getConversationList");
        this.$store.dispatch("conversation/getUnReadCount");
        this.$store.commit("user/SET_IS_SYNCING", false);
      };
      const syncFailedHandler = () => {
        uni.hideLoading();
        uni.$u.toast("同步消息失败");
        this.$store.dispatch("conversation/getConversationList");
        this.$store.dispatch("conversation/getUnReadCount");
        this.$store.commit("user/SET_IS_SYNCING", false);
      };
      IMSDK.subscribe(IMSDK.IMEvents.OnSyncServerStart, syncStartHandler);
      IMSDK.subscribe(IMSDK.IMEvents.OnSyncServerFinish, syncFinishHandler);
      IMSDK.subscribe(IMSDK.IMEvents.OnSyncServerFailed, syncFailedHandler);

      // self
      const selfInfoUpdateHandler = ({ data }) => {
        this.$store.commit("user/SET_SELF_INFO", {
          ...this.storeSelfInfo,
          ...data,
        });
      };

      IMSDK.subscribe(IMSDK.IMEvents.OnSelfInfoUpdated, selfInfoUpdateHandler);

      // message
      const newMessagesHandler = ({ data }) => {
        if (this.storeIsSyncing) {
          return;
        }
        data.forEach(this.handleNewMessage);
      };

      IMSDK.subscribe(IMSDK.IMEvents.OnRecvNewMessages, newMessagesHandler);

      // friend
      const friendInfoChangeHandler = ({ data }) => {
        console.log(data);
        if (data.userID === this.storeCurrentConversation?.userID) {
          this.updateMessageNicknameAndFaceUrl({
            sendID: data.userID,
            senderNickname: data.nickname,
            senderFaceUrl: data.faceURL,
          });
          this.$store.commit(
            "conversation/SET_CURRENT_CONVERSATION",
            { ...this.storeCurrentConversation, showName: data.nickname },
          );
        }
        console.log(this.storeConversationList)
        this.updateFriendInfo({
          friendInfo: data,
        });
      };
      const friendAddedHandler = ({ data }) => {
        this.pushNewFriend(data);
      };
      const friendDeletedHander = ({ data }) => {
        this.updateFriendInfo({
          friendInfo: data,
          isRemove: true,
        });
      };

      IMSDK.subscribe(
        IMSDK.IMEvents.OnFriendInfoChanged,
        friendInfoChangeHandler,
      );
      IMSDK.subscribe(IMSDK.IMEvents.OnFriendAdded, friendAddedHandler);
      IMSDK.subscribe(IMSDK.IMEvents.OnFriendDeleted, friendDeletedHander);

      // blacklist
      const blackAddedHandler = ({ data }) => {
        this.pushNewBlack(data);
      };
      const blackDeletedHandler = ({ data }) => {
        this.updateBlackInfo({
          blackInfo: data,
          isRemove: true,
        });
      };

      IMSDK.subscribe(IMSDK.IMEvents.OnBlackAdded, blackAddedHandler);
      IMSDK.subscribe(IMSDK.IMEvents.OnBlackDeleted, blackDeletedHandler);

      // group
      const joinedGroupAddedHandler = ({ data }) => {
        this.pushNewGroup(data);
      };
      const joinedGroupDeletedHandler = ({ data }) => {
        this.updateGroupInfo({
          groupInfo: data,
          isRemove: true,
        });
      };
      const groupInfoChangedHandler = ({ data }) => {
        this.updateGroupInfo({
          groupInfo: data,
        });
      };
      const groupMemberInfoChangedHandler = ({ data }) => {
        if (data.groupID === this.storeCurrentConversation?.groupID) {
          this.updateMessageNicknameAndFaceUrl({
            sendID: data.userID,
            senderNickname: data.nickname,
            senderFaceUrl: data.faceURL,
          });
          this.updateCurrentMemberInGroup(data);
        }
      };

      IMSDK.subscribe(
        IMSDK.IMEvents.OnJoinedGroupAdded,
        joinedGroupAddedHandler,
      );
      IMSDK.subscribe(
        IMSDK.IMEvents.OnJoinedGroupDeleted,
        joinedGroupDeletedHandler,
      );
      IMSDK.subscribe(
        IMSDK.IMEvents.OnGroupInfoChanged,
        groupInfoChangedHandler,
      );
      IMSDK.subscribe(
        IMSDK.IMEvents.OnGroupMemberInfoChanged,
        groupMemberInfoChangedHandler,
      );

      // application
      const friendApplicationNumHandler = ({ data }) => {
        const isRecv = data.toUserID === this.storeCurrentUserID;
        if (isRecv) {
          this.pushNewRecvFriendApplition(data);
        } else {
          this.pushNewSentFriendApplition(data);
        }
      };
      const friendApplicationAccessHandler = ({ data }) => {
        const isRecv = data.toUserID === this.storeCurrentUserID;
        if (isRecv) {
          this.updateRecvFriendApplition({
            application: data,
          });
        } else {
          this.updateSentFriendApplition({
            application: data,
          });
        }
      };
      const groupApplicationNumHandler = ({ data }) => {
        const isRecv = data.userID !== this.storeCurrentUserID;
        if (isRecv) {
          this.pushNewRecvGroupApplition(data);
        } else {
          this.pushNewSentGroupApplition(data);
        }
      };
      const groupApplicationAccessHandler = ({ data }) => {
        const isRecv = data.userID !== this.storeCurrentUserID;
        if (isRecv) {
          this.updateRecvGroupApplition({
            application: data,
          });
        } else {
          this.updateSentGroupApplition({
            application: data,
          });
        }
      };

      IMSDK.subscribe(
        IMSDK.IMEvents.OnFriendApplicationAdded,
        friendApplicationNumHandler,
      );
      IMSDK.subscribe(
        IMSDK.IMEvents.OnFriendApplicationAccepted,
        friendApplicationAccessHandler,
      );
      IMSDK.subscribe(
        IMSDK.IMEvents.OnFriendApplicationRejected,
        friendApplicationAccessHandler,
      );
      IMSDK.subscribe(
        IMSDK.IMEvents.OnGroupApplicationAdded,
        groupApplicationNumHandler,
      );
      IMSDK.subscribe(
        IMSDK.IMEvents.OnGroupApplicationAccepted,
        groupApplicationAccessHandler,
      );
      IMSDK.subscribe(
        IMSDK.IMEvents.OnGroupApplicationRejected,
        groupApplicationAccessHandler,
      );

      // conversation
      const totalUnreadCountChangedHandler = ({ data }) => {
        if (this.storeIsSyncing) {
          return;
        }
        this.$store.commit("conversation/SET_UNREAD_COUNT", data);
      };
      const newConversationHandler = ({ data }) => {
        if (this.storeIsSyncing) {
          return;
        }
        const result = [...data, ...this.storeConversationList];
        this.$store.commit(
          "conversation/SET_CONVERSATION_LIST",
          conversationSort(result),
        );
      };
      const conversationChangedHandler = ({ data }) => {
        if (this.storeIsSyncing) {
          return;
        }
        let filterArr = [];
        console.log(data);
        const chids = data.map((ch) => ch.conversationID);
        filterArr = this.storeConversationList.filter(
          (tc) => !chids.includes(tc.conversationID),
        );
        const idx = data.findIndex(
          (c) =>
            c.conversationID === this.storeCurrentConversation.conversationID,
        );
        if (idx !== -1)
          this.$store.commit(
            "conversation/SET_CURRENT_CONVERSATION",
            data[idx],
          );
        const result = [...data, ...filterArr];
        this.$store.commit(
          "conversation/SET_CONVERSATION_LIST",
          conversationSort(result),
        );
      };

      IMSDK.subscribe(
        IMSDK.IMEvents.OnTotalUnreadMessageCountChanged,
        totalUnreadCountChangedHandler,
      );
      IMSDK.subscribe(IMSDK.IMEvents.OnNewConversation, newConversationHandler);
      IMSDK.subscribe(
        IMSDK.IMEvents.OnConversationChanged,
        conversationChangedHandler,
      );
    },

    setPageListener() {
      uni.$on(PageEvents.CheckForUpdate, this.checkVersion);
    },
    tryLogin() {
      const initStore = () => {
        this.$store.dispatch("user/getSelfInfo");
        this.$store.dispatch("conversation/getConversationList");
        this.$store.dispatch("conversation/getUnReadCount");
        this.$store.dispatch("contact/getFriendList");
        this.$store.dispatch("contact/getGrouplist");
        this.$store.dispatch("contact/getBlacklist");
        this.$store.dispatch("contact/getRecvFriendApplications");
        this.$store.dispatch("contact/getSentFriendApplications");
        this.$store.dispatch("contact/getRecvGroupApplications");
        this.$store.dispatch("contact/getSentGroupApplications");
        uni.switchTab({
          url: "/pages/conversation/conversationList/index?isRedirect=true",
        });
      };
      getDbDir()
        .then(async (path) => {
          const flag = await IMSDK.asyncApi(IMMethods.InitSDK, IMSDK.uuid(), {
            platformID: uni.$u.os() === "ios" ? 1 : 2, // 平台，参照IMPlatform类,
            apiAddr: config.getApiUrl(), // SDK的API接口地址。如：http://xxx:10002
            wsAddr: config.getWsUrl(), // SDK的websocket地址。如： ws://xxx:10001
            dataDir: path, // 数据存储路径
            logLevel: 6,
            logFilePath: path,
            isLogStandardOutput: true,
            isExternalExtensions: false,
          });
          if (!flag) {
            plus.navigator.closeSplashscreen();
            uni.$u.toast("初始化IMSDK失败！");
            return;
          }
          const status = await IMSDK.asyncApi(
            IMSDK.IMMethods.GetLoginStatus,
            IMSDK.uuid(),
          );
          if (status === 3) {
            initStore();
            return;
          }

          const IMToken = uni.getStorageSync("IMToken");
          const IMUserID = uni.getStorageSync("IMUserID");
          if (IMToken && IMUserID) {
            IMSDK.asyncApi(IMSDK.IMMethods.Login, IMSDK.uuid(), {
              userID: IMUserID,
              token: IMToken,
            })
              .then(initStore)
              .catch((err) => {
                console.log(err);
                uni.removeStorage({
                  key: "IMToken",
                });
                uni.removeStorage({
                  key: "BusinessToken",
                });
                plus.navigator.closeSplashscreen();
              });
          } else {
            plus.navigator.closeSplashscreen();
          }
        })
        .catch((err) => {
          console.log("get dir failed");
          console.log(err);
          plus.navigator.closeSplashscreen();
        });
    },

    launchCheck() {
      plus.globalEvent.addEventListener("newintent", (e) => {
        console.log(plus.runtime.arguments);
        let launchData = {};
        try {
          launchData = JSON.parse(plus.runtime.arguments);
        } catch (e) { }
        switch (launchData.type) {
          case "updateDownloadFinish":
            break;
          case "updateProgress":
            if (pausing) return;

            if (updateDownloadTask?.state === 5) {
              updateDownloadTask?.resume();
            } else {
              updateDownloadTask?.pause();
              this.updateNotification("暂停中");
              pausing = true;
            }
            break;
          default:
            break;
        }
      });
    },
    checkVersion(initiative = false) {
      if (uni.$u.os() === "ios") {
        return;
      }
      plus.runtime.getProperty(plus.runtime.appid, ({ version }) => {
        checkUpdateFormPgyer(version)
          .then(
            async ({
              buildHaveNewVersion,
              needForceUpdate,
              downloadURL,
              buildUpdateDescription,
              buildVersion,
            }) => {
              if (buildHaveNewVersion) {
                const hasDownloadedPath =
                  await this.checkDownloadedPkg(buildVersion);
                uni.showModal({
                  title: "检测到新版本",
                  content: hasDownloadedPath
                    ? "新版本已下载完毕，是否立即更新？"
                    : buildUpdateDescription || "",
                  showCancel: !needForceUpdate,
                  confirmText: hasDownloadedPath ? "立即更新" : "立即升级",
                  cancelText: "下次再说",
                  success: (res) => {
                    if (res.confirm) {
                      if (hasDownloadedPath) {
                        plus.runtime.install(hasDownloadedPath);
                      } else {
                        this.downloadApk(downloadURL, buildVersion);
                      }
                    } else {
                      if (needForceUpdate) {
                        plus.runtime.quit();
                      }
                    }
                  },
                });
              }

              if (initiative && !buildHaveNewVersion) {
                uni.$u.toast("当前已是最新版本！");
              }
            },
          )
          .catch((err) => {
            console.log(err);
            if (initiative) {
              uni.$u.toast("获取版本信息失败！");
            }
          })
          .finally(
            () => initiative && uni.$emit(PageEvents.CheckForUpdateResp),
          );
      });
    },
    async checkDownloadedPkg(buildVersion) {
      const versionMap = uni.getStorageSync("IMVersionMap") || {};
      const filePath = versionMap[buildVersion];
      const [err] = await uni.getSavedFileInfo({
        filePath,
      });
      return err ? "" : filePath;
    },
    downloadApk(downloadURL, buildVersion) {
      notificationIntance = new NotificationUtil();
      updateDownloadTask = plus.downloader.createDownload(downloadURL);

      updateDownloadTask.addEventListener("statechanged", (task, status) => {
        if (task.state === 3) {
          uni.$u.throttle(() => this.updateNotification("正在下载..."), 1000);
        }

        if (task.state === 5) {
          this.updateNotification("已暂停", true);
          pausing = false;
        }

        if (task.state === 4) {
          if (status === 200) {
            this.updateNotification("正在下载...");
            setTimeout(() => this.downloadFinish(buildVersion), 200);
          }
        }
      });
      updateDownloadTask.start();
    },
    updateNotification(content, isPause = false) {
      const progress = parseInt(
        (updateDownloadTask.downloadedSize / updateDownloadTask.totalSize) *
        100,
      );
      const config = {
        progress,
        isPause,
        title: "OpenIM",
        content: `${content}${progress}%`,
        intentList: [["type", "updateProgress"]],
      };
      notificationIntance.createProgress(config);
    },
    downloadFinish(buildVersion) {
      notificationIntance.clearNotification(1000);
      notificationIntance.compProgressNotification({
        title: "OpenIM",
        content: "下载完成",
        notifyId: 1001,
      });
      uni.showModal({
        title: "准备更新",
        content: "安装包已下载完毕，是否立即更新？",
        showCancel: false,
        confirmText: "立即更新",
        success: (res) => {
          const pkgPath = plus.io.convertLocalFileSystemURL(
            updateDownloadTask.filename,
          );
          if (res.confirm) {
            plus.runtime.install(pkgPath);
          } else {
            const versionMap = uni.getStorageSync("IMVersionMap") || {};
            versionMap[buildVersion] = pkgPath;
            uni.setStorage({
              key: "IMVersionMap",
              data: versionMap,
            });
          }
        },
      });
    },

    async newMessageNotify(newServerMsg) {
      if (this.storeIsSyncing) {
        return;
      }

      const disableNotify = uni.getStorageSync(
        `${this.storeCurrentUserID}_DisableNotify`,
      );
      if (
        disableNotify ||
        this.storeSelfInfo.globalRecvMsgOpt !== MessageReceiveOptType.Nomal
      ) {
        return;
      }

      let cveItem = [
        ...this.storeConversationList,
        ...cacheConversationList,
      ].find((conversation) => {
        if (newServerMsg.sessionType === SessionType.WorkingGroup) {
          return newServerMsg.groupID === conversation.groupID;
        }
        return newServerMsg.sendID === conversation.userID;
      });

      if (!cveItem) {
        try {
          const { data } = await IMSDK.asyncApi(
            IMSDK.IMMethods.GetOneConversation,
            IMSDK.uuid(),
            {
              sourceID: newServerMsg.groupID || newServerMsg.sendID,
              sessionType: newServerMsg.sessionType,
            },
          );
          cveItem = data;
          cacheConversationList = [...cacheConversationList, data];
        } catch (e) {
          return;
        }
      }

      if (cveItem.recvMsgOpt !== MessageReceiveOptType.Nomal) {
        return;
      }

      // uni.createPushMessage({
      // 	content: `${newServerMsg.senderNickname}: ${parseMessageByType(newServerMsg)}`,
      // 	payload: {
      // 		sessionType: newServerMsg.sessionType,
      // 		sourceID: newServerMsg.groupID || newServerMsg.sendID,
      // 	}
      // })

      const platform = uni.getSystemInfoSync().platform;
      if (platform == "ios") {
        if (this.storeSelfInfo.allowVibration === 1) {
          plus.device.vibrate();
        }

        if (this.storeSelfInfo.allowBeep === 1) {
          innerAudioContext.play();
          // plus.device.beep();
        }
      } else if (platform == "android") {
        if (this.storeSelfInfo.allowVibration === 1) {
          plus.device.vibrate(500);
        }
        if (this.storeSelfInfo.allowBeep === 1) {
          let main = plus.android.runtimeMainActivity();
          let RingtoneManager = plus.android.importClass(
            "android.media.RingtoneManager",
          );
          let uri = RingtoneManager.getActualDefaultRingtoneUri(
            main,
            RingtoneManager.TYPE_NOTIFICATION,
          );
          let MediaPlayer = plus.android.importClass(
            "android.media.MediaPlayer",
          );
          let player = MediaPlayer.create(main, uri);
          player.setLooping(false);
          player.prepare();
          player.start();
        }
      }
    },
    handleNewMessage(newServerMsg) {
      if (this.inCurrentConversation(newServerMsg)) {
        const isSingleMessage = newServerMsg.sessionType === SessionType.Single;

        if (isSingleMessage) {
          uni.$u.throttle(() => uni.$emit(PageEvents.OnlineStateCheck), 2000);
        }

        if (newServerMsg.contentType === MessageType.TypingMessage) {
          if (isSingleMessage) {
            uni.$emit(PageEvents.TypingUpdate);
          }
        } else {
          if (newServerMsg.contentType === MessageType.RevokeMessage) {
          } else {
            newServerMsg.isAppend = true;
            this.pushNewMessage(newServerMsg);
            setTimeout(() => uni.$emit(PageEvents.ScrollToBottom, true));
          }
          uni.$u.debounce(this.markConversationAsRead, 2000);
        }
      } else {
        if (newServerMsg.contentType !== MessageType.TypingMessage) {
          uni.$u.throttle(() => this.newMessageNotify(newServerMsg), 1000);
        }
      }
    },
    inCurrentConversation(newServerMsg) {
      switch (newServerMsg.sessionType) {
        case SessionType.Single:
          return (
            newServerMsg.sendID === this.storeCurrentConversation.userID ||
            (newServerMsg.sendID === this.storeCurrentUserID &&
              newServerMsg.recvID === this.storeCurrentConversation.userID)
          );
        case SessionType.WorkingGroup:
          return newServerMsg.groupID === this.storeCurrentConversation.groupID;
        case SessionType.Notification:
          return newServerMsg.sendID === this.storeCurrentConversation.userID;
        default:
          return false;
      }
    },
    markConversationAsRead() {
      IMSDK.asyncApi(
        IMSDK.IMMethods.MarkConversationMessageAsRead,
        IMSDK.uuid(),
        this.storeCurrentConversation.conversationID,
      );
    },
  },
  watch: {
    storeCurrentUserID(newVal) {
      if (newVal) {
        cacheConversationList = [];
      }
    },
    contactBadgeRely: {
      handler(newValue) {
        const { recvFriendApplications, recvGroupApplications, userKey } =
          newValue;
        if (!userKey) return;
        const accessedFriendApplications =
          uni.getStorageSync(`${userKey}_accessedFriendApplications`) || [];
        let unHandleFriendApplicationNum = recvFriendApplications.filter(
          (application) =>
            application.handleResult === 0 &&
            !accessedFriendApplications.includes(
              `${application.fromUserID}_${application.createTime}`,
            ),
        ).length;
        const accessedGroupApplications =
          uni.getStorageSync(`${userKey}_accessedGroupApplications`) || [];
        let unHandleGroupApplicationNum = recvGroupApplications.filter(
          (application) =>
            application.handleResult === 0 &&
            !accessedGroupApplications.includes(
              `${application.userID}_${application.createTime}`,
            ),
        ).length;
        const total =
          unHandleFriendApplicationNum + unHandleGroupApplicationNum;
        if (total) {
          uni.setTabBarBadge({
            index: 1,
            text: total < 99 ? total + "" : "99+",
          });
        } else {
          uni.removeTabBarBadge({
            index: 1,
          });
        }
        this.$store.commit(
          "contact/SET_UNHANDLE_FRIEND_APPLICATION_NUM",
          unHandleFriendApplicationNum,
        );
        this.$store.commit(
          "contact/SET_UNHANDLE_GROUP_APPLICATION_NUM",
          unHandleGroupApplicationNum,
        );
      },
      deep: true,
    },
  },
};
</script>

<style lang="scss">
/*每个页面公共css */
@import "@/uni_modules/uview-ui/index.scss";
@import "@/styles/login.scss";
@import "@/styles/global.scss";


uni-page-body {
  height: 100vh;
  overflow: hidden;
}

.uni-tabbar .uni-tabbar__icon {
  width: 28px !important;
  height: 28px !important;
}
</style>
