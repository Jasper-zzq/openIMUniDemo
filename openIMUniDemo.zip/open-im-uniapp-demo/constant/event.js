export const PageEvents = {
  PreviewVideo: "PreviewVideo",
  TypingUpdate: "TypingUpdate",
  OnlineStateCheck: "OnlineStateCheck",
  GlobalToast: "GlobalToast",
  ScrollToBottom: "ScrollToBottom",
  AtSomeOne: "AtSomeOne",
  MutipleCheckUpdate: "MutipleCheckUpdate",
  CheckForUpdate: "CheckForUpdate",
  CheckForUpdateResp: "CheckForUpdateResp",
};
