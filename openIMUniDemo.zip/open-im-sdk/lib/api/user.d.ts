import type { GetUserInfoWithCacheParams } from '@/types/params';
import IMSDK from '.';
import type { MessageReceiveOptType } from '@/types/enum';
import type { FullUserItemWithCache, SelfUserInfo, UserOnlineState, WsResponse } from '@/types/entity';
export declare function setupUser(openIMSDK: IMSDK): {
    getSelfUserInfo: (operationID?: string) => Promise<WsResponse<SelfUserInfo>>;
    setSelfInfo: (params: Partial<SelfUserInfo>, operationID?: string) => Promise<WsResponse<unknown>>;
    getUsersInfoWithCache: (params: GetUserInfoWithCacheParams, operationID?: string) => Promise<WsResponse<FullUserItemWithCache[]>>;
    subscribeUsersStatus: (params: string[], operationID?: string) => Promise<WsResponse<UserOnlineState>>;
    unsubscribeUsersStatus: (params: string[], operationID?: string) => Promise<WsResponse<unknown>>;
    getSubscribeUsersStatus: (operationID?: string) => Promise<WsResponse<UserOnlineState[]>>;
    setAppBackgroundStatus: (params: boolean, operationID?: string) => Promise<WsResponse<unknown>>;
    networkStatusChanged: (operationID?: string) => Promise<WsResponse<unknown>>;
    setGlobalRecvMessageOpt: (params: MessageReceiveOptType, operationID?: string) => Promise<WsResponse<unknown>>;
};
export interface UserApi {
    getSelfUserInfo: (operationID?: string) => Promise<WsResponse<SelfUserInfo>>;
    setSelfInfo: (params: Partial<SelfUserInfo>, operationID?: string) => Promise<WsResponse<unknown>>;
    getUsersInfoWithCache: (params: GetUserInfoWithCacheParams, operationID?: string) => Promise<WsResponse<FullUserItemWithCache[]>>;
    subscribeUsersStatus: (params: string[], operationID?: string) => Promise<WsResponse<UserOnlineState>>;
    unsubscribeUsersStatus: (params: string[], operationID?: string) => Promise<WsResponse<unknown>>;
    getSubscribeUsersStatus: (operationID?: string) => Promise<WsResponse<UserOnlineState[]>>;
    setAppBackgroundStatus: (params: boolean, operationID?: string) => Promise<WsResponse<unknown>>;
    networkStatusChanged: (operationID?: string) => Promise<WsResponse<unknown>>;
    setGlobalRecvMessageOpt: (params: MessageReceiveOptType, operationID?: string) => Promise<WsResponse<unknown>>;
}
