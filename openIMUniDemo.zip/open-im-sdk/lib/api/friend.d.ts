import type { AccessFriendParams, RemarkFriendParams, SearchFriendParams } from '@/types/params';
import IMSDK from '.';
import type { BlackUserItem, FriendApplicationItem, FriendshipInfo, WsResponse, SearchedFriendsInfo, FullUserItem } from '@/types/entity';
export declare function setupFriend(openIMSDK: IMSDK): {
    acceptFriendApplication: (params: AccessFriendParams, operationID?: string) => Promise<WsResponse<unknown>>;
    addBlack: (params: string, operationID?: string) => Promise<WsResponse<unknown>>;
    addFriend: (params: string, operationID?: string) => Promise<WsResponse<unknown>>;
    checkFriend: (params: string[], operationID?: string) => Promise<WsResponse<FriendshipInfo[]>>;
    deleteFriend: (params: string, operationID?: string) => Promise<WsResponse<unknown>>;
    getBlackList: (operationID?: string) => Promise<WsResponse<BlackUserItem[]>>;
    getFriendApplicationListAsApplicant: (operationID?: string) => Promise<WsResponse<FriendApplicationItem[]>>;
    getFriendApplicationListAsRecipient: (operationID?: string) => Promise<WsResponse<FriendApplicationItem[]>>;
    getFriendList: (operationID?: string) => Promise<WsResponse<FullUserItem[]>>;
    getSpecifiedFriendsInfo: (params: string[], operationID?: string) => Promise<WsResponse<FullUserItem[]>>;
    refuseFriendApplication: (params: AccessFriendParams, operationID?: string) => Promise<WsResponse<unknown>>;
    removeBlack: (params: string, operationID?: string) => Promise<WsResponse<unknown>>;
    searchFriends: (params: SearchFriendParams, operationID?: string) => Promise<WsResponse<SearchedFriendsInfo[]>>;
    setFriendRemark: (params: RemarkFriendParams, operationID?: string) => Promise<WsResponse<unknown>>;
};
export interface FriendApi {
    acceptFriendApplication: (params: AccessFriendParams, operationID?: string) => Promise<WsResponse<unknown>>;
    addBlack: (params: string, operationID?: string) => Promise<WsResponse<unknown>>;
    addFriend: (params: string, operationID?: string) => Promise<WsResponse<unknown>>;
    checkFriend: (params: string[], operationID?: string) => Promise<WsResponse<FriendshipInfo[]>>;
    deleteFriend: (params: string, operationID?: string) => Promise<WsResponse<unknown>>;
    getBlackList: (operationID?: string) => Promise<WsResponse<BlackUserItem[]>>;
    getFriendApplicationListAsApplicant: (operationID?: string) => Promise<WsResponse<FriendApplicationItem[]>>;
    getFriendApplicationListAsRecipient: (operationID?: string) => Promise<WsResponse<FriendApplicationItem[]>>;
    getFriendList: (operationID?: string) => Promise<WsResponse<FullUserItem[]>>;
    getSpecifiedFriendsInfo: (params: string[], operationID?: string) => Promise<WsResponse<FullUserItem[]>>;
    refuseFriendApplication: (params: AccessFriendParams, operationID?: string) => Promise<WsResponse<unknown>>;
    removeBlack: (params: string, operationID?: string) => Promise<WsResponse<unknown>>;
    searchFriends: (params: SearchFriendParams, operationID?: string) => Promise<WsResponse<SearchedFriendsInfo[]>>;
    setFriendRemark: (params: RemarkFriendParams, operationID?: string) => Promise<WsResponse<unknown>>;
}
