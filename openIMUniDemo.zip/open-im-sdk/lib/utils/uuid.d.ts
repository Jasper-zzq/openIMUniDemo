export declare const uuid: () => string;
