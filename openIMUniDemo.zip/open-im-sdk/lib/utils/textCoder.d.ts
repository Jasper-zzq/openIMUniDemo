export declare function utf8Encode(str: string): ArrayBuffer;
export declare function utf8Decode(buffer: ArrayBuffer): string;
