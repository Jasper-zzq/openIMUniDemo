import { CommonOptions, ConfirmData, UploadData, UploadParams } from '@/types/upload';
export declare const getUploadPartsize: (baseUrl: string, size: number, commonOptions: CommonOptions) => Promise<{
    size: number;
}>;
export declare const getUploadUrl: (baseUrl: string, params: UploadParams, commonOptions: CommonOptions) => Promise<UploadData>;
export declare const confirmUpload: (baseUrl: string, params: ConfirmData, commonOptions: CommonOptions) => Promise<{
    url: string;
}>;
export declare const getMimeType: (fileName: string) => string;
