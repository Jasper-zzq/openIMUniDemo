import type { WsRequest, WsResponse } from '@/types/entity';
declare class WebSocketManager {
    private onMessage;
    private onReconnectSuccess;
    private ws?;
    private url;
    private reconnectInterval;
    private maxReconnectAttempts;
    private reconnectAttempts;
    private shouldReconnect;
    private isProcessingMessage;
    private platformNamespace;
    constructor(url: string, onMessage: (data: WsResponse) => void, onReconnectSuccess: () => void, reconnectInterval?: number, maxReconnectAttempts?: number);
    private checkPlatform;
    connect: () => Promise<void>;
    private setupEventListeners;
    private onBinaryMessage;
    private encodeMessage;
    sendMessage: (message: WsRequest) => void;
    close: () => void;
}
export default WebSocketManager;
